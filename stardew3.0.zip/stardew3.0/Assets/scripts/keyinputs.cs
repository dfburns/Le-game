using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using static UnityEditor.Progress;

public class keyinputs : MonoBehaviour
{
    public Tilemap[] tilemap;

    public TileBase[] placing;

    public GameObject inventorySlotPrefab; // Prefab/UI element representing an inventory slot

    public GameObject interactionsprefab;


    // Update is called once per frame
    void Update()
    {
        if (Keyboard.current.qKey.wasPressedThisFrame)
        {
            // Convert the hit point to tile coordinates
            Vector3Int cellPosition = playercontroller.position;
            TileBase tile = playercontroller.tilebase;
            if (playercontroller.interacting == null)
            {
                if(Items.holdingobject != null)
                {                        
                    Vector3Int rbposition = tilemap[1].WorldToCell(playercontroller.rb.position);

                    if (Items.holdingobject.name == "slime_0")
                    {
                        Debug.Log("Player position in cell coordinates: " + rbposition);
                        tilemap[1].SetTile(rbposition, placing[0]);
                    }
                    if(Items.holdingobject.name == "chest_02_1")
                    {   TileBase dirt = tilemap[1].GetTile(rbposition);
                        if (dirt.name == "dirt")
                        {
                            tilemap[1].SetTile(rbposition, placing[1]);
                        }
                    }

                }

            }
            else
            {

                if (tile != null && playercontroller.interacting.gameObject.name == "items")
                {

                    // remove the tile from the Tilemap
                    tilemap[3].SetTile(cellPosition, null);

                    GameObject slot = Instantiate(inventorySlotPrefab, gameObject.transform);
                    // Create an item instance and add it to the inventory
                    Items item = slot.GetComponent<Items>();
                    item.itemName = ((Tile)tile).sprite.name; // Set item name

                    slot.name = item.itemName;
                    // Set the item's icon to the sprite of the tile being destroyed
                    item.icon = ((Tile)tile).sprite;
                    // Add the item to the inventory
                    playercontroller.AddItemToInventory(item);

                    Image slotImage = slot.GetComponent<Image>();
                    slotImage.sprite = item.icon;

                    Debug.Log("Picked up item: " + item.itemName);
                    playercontroller.interacting = null;
                }
                else if (tile != null && playercontroller.interacting.gameObject.name == "people")
                {
                    interactionsprefab.SetActive(true);
                    Debug.Log(((Tile)tile).sprite.name);
                    if (((Tile)tile).sprite.name == "player_11")
                    {
                        player_26.characterdecision();
                    }
                    else if (((Tile)tile).sprite.name == "player_50")
                    {
                        player_50.characterdecision();
                    }
                    playercontroller.interacting = null;
                }
            }
        }
    }
}
