using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.Progress;

public class Items : MonoBehaviour
{
    public  static List<Items> inventory = new List<Items>();
    public string itemName;
    public Sprite icon;

    public static GameObject holdingobject;


    public void holding()
    {
        holdingobject = gameObject;
    }


}
