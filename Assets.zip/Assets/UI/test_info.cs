using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class test_info : MonoBehaviour
{

    public static void interactwith(Collider2D hits)
    {
        GameObject.Find("interact").GetComponent<TextMeshProUGUI>().text = "Interacting with: "+ hits.gameObject.name;
    }

}
