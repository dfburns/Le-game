using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.Timeline;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.UIElements;

public class plants : MonoBehaviour
{
    public float plantedtime;
    public float wateredtime;
    public string Name;
    public string Type;
    public Boolean iswatered;
    public Boolean isharvestable;
    public int arrayat = 0;
    public Vector3Int location;

    // Start is called before the first frame update
    void Start()
    {
     }

    // Method to add an item to the map with inline array values
    // Update is called once per frame
    void Update()
    {

        GameObject allplants = GameObject.Find("plantscontroller");
        for (int i = 0; i < allplants.transform.childCount; i++)
        {

            GameObject gameObject = allplants.transform.GetChild(i).gameObject;

            plants plant = gameObject.GetComponent<plants>();
            if((plant.plantedtime + 3) <= daynight.time &&
                plant.arrayat != 1)
            {
                Debug.Log("does it go here?");
                ++plant.arrayat;
                keyinputs.statictilemap[1].SetTile(plant.location, planting.tilebases[plant.arrayat][planting.GetValue(plant.Name)[plant.arrayat]]);
                plant.plantedtime = daynight.time;
            }
            if (plant.wateredtime + 2 >= daynight.time)
            {
                plant.iswatered = false;
            }

        }
    }
}
