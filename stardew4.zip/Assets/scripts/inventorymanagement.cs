using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class inventorymanagement : MonoBehaviour
{
    public static inventorymanagement instance;
    public int maxstack = 4;

    public static Dictionary<string, Items> itemsdic = new Dictionary<string, Items>();
    public Items[] items;
    public inventoryslots[] inventoryslots; 
    public GameObject inventoryitemprefab;

    int selectedslot = 0;


    private void Start()
    {
        changeselectedlsot(0);
    }

    private void Update()
    {
        if(Input.inputString != null)
        {
            bool isNumber = int.TryParse(Input.inputString, out int number);
            if(isNumber && number > 0 && number < 7 )
            {
                changeselectedlsot(number - 1);
            }
        }
    }

    public Items GetSelectedItem(bool use)
    {
        inventoryslots slot = inventoryslots[selectedslot];
        inventoryitem iteminslot = slot.GetComponentInChildren<inventoryitem>();
        if(iteminslot != null)
        {
            Items item = iteminslot.item;
            if(use == true)
            {
                iteminslot.count--;
                iteminslot.RefreshCount();
                if(iteminslot.count <= 0 ) 
                {
                Destroy(iteminslot.gameObject);
                }
            }
            return item;
        }
        Debug.Log("no item recieved");
        return null; 
    }

    void changeselectedlsot(int newvalue)
    {
        if(selectedslot >= 0) {
            inventoryslots[selectedslot].deselect();
        }

        inventoryslots[newvalue].select();
        selectedslot = newvalue;
        test_info.holding(GetSelectedItem(false));
    }

    private void Awake()
    {
        instance = this;
        itemsdic.Add("slime_0", items[1]);
        itemsdic.Add("seed on grund", items[0]);
    }

    public static bool ContainsKey(string key)
    {
        return itemsdic.ContainsKey(key);
    }

    public static Items GetValue(string key)
    {
        if (itemsdic.ContainsKey(key))
            return itemsdic[key];
        else
            return null; // Or return an empty array or handle as needed
    }
    public bool AddItem(Items items)
    {
        for (int i = 0; i < inventoryslots.Length; i++)
        {
            inventoryslots slot = inventoryslots[i];
            inventoryitem inventoryitem = slot.GetComponentInChildren<inventoryitem>();
            if (inventoryitem != null &&
                inventoryitem.item == items &&
                inventoryitem.count < maxstack &&
                inventoryitem.item.stacable == true)
            {
                inventoryitem.count++;
                inventoryitem.RefreshCount();
                return true;
            }
        }

        for (int i = 0; i < inventoryslots.Length; i++)
        {
            inventoryslots slot = inventoryslots[i];
            inventoryitem inventoryitem = slot.GetComponentInChildren<inventoryitem>();
            if(inventoryitem == null)
            {
                Spawnnewitem(items, slot);
                return true;
            }
        }
        Debug.Log("item not added");
        return false;
    }

    void Spawnnewitem(Items items, inventoryslots slot)
    {
        GameObject mewitemgo = Instantiate(inventoryitemprefab, slot.transform);
        inventoryitem mewitem = mewitemgo.GetComponent<inventoryitem>();
        mewitem.Initializeditem(items);
    }
}
