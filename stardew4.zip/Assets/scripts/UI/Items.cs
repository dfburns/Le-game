using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.Progress;
using UnityEngine.Tilemaps;
using UnityEngine.InputSystem;
using UnityEngine.UI;

[CreateAssetMenu(menuName = "Scriptable object/Item")]
public class Items : ScriptableObject
{
    public string itemName;
    public Sprite image;
    public ActionType actiontype;
    public ItemType type;
    public Vector2Int range = new Vector2Int(5,4);
    public bool stacable = true;

    //public static GameObject holdingobject;


    public enum ItemType
    {
        seed,
        Tool
    }

    public enum ActionType
    {
        Dig,
        Mine
    }



}
